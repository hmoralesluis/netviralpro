<?php

namespace App\ContentManagementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ContentManagementBundle extends Bundle
{
}
